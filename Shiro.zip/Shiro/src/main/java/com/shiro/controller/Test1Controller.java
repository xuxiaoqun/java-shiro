package com.shiro.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shiro.realm.User;

@RestController
public class Test1Controller {

	// 由于TestController类上没有加@RequiresAuthentication注解，
	// 不要求用户登录才能调用接口,可以匿名访问的
	@GetMapping("/index.do")
	public String hello() {
		return "hello spring boot";
	}

	// 已登录用户才能访问，这个注解比@RequiresUser更严格
	// 如果用户未登录调用该接口，会抛出UnauthenticatedException
	@RequiresAuthentication
	@GetMapping("/authn")
	public String authn() {
		return "@RequiresAuthentication";
	}

	
	
	/**
     * 登录接口，由于UserService中是模拟返回用户信息的，
     * 所以用户名随意，密码123456
     *
     * @param body
     * @return
     */
    @GetMapping("/login")
    public String login(){
    	//添加用户认证的信息
    	Subject subject = SecurityUtils.getSubject();
    	UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken("test","123456");
    	subject.login(usernamePasswordToken);
    	return "ok";
    }
    

    //错误页面展示
    @GetMapping(value = "/error.do")
    public String error(){
        return "error ok!";
    }


    //登出页面展示
    @GetMapping(value = "/logout.do")
    public String logout(){
    	Subject subject = SecurityUtils.getSubject();
    	subject.logout();
        return "logout successful";
    }
    
    @RequiresRoles("java")
	@GetMapping("/java")
	public String java() {
		return "java programmer";
	}

    @RequiresRoles("js1")
	@GetMapping("/js1")
	public String js1() {
		return "js1 programmer";
	}
    

	@RequiresPermissions("html:edit")
	@GetMapping("/edit")
	public String edit() {
		return "html:edit";
	}
	
	@RequiresPermissions("html:read")
	@GetMapping("/read")
	public String read() {
		return "html:read";
	}
}
