package com.shiro.service;

import java.util.Date;
import java.util.Random;

import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Service;

import com.shiro.realm.User;

@Service
public class UserService {

	/**
	 * 模拟查询返回用户信息
	 * 
	 * @param uname
	 * @return
	 */
	public User findUserByName(String uname) {
		User user = new User();
		user.setUname(uname);
		user.setNick(uname + "NICK");
		user.setPwd("wfNTT3T/DByapLuAP8IduPlp0L1fKna34cAjgs/zVVg=");// 密码明文是123456
		user.setSalt("123456");// 加密密码的盐值
		user.setUid(new Random().nextLong());// 随机分配一个id
		user.setCreated(new Date());
		return user;
	}

	/**
	 * 密码加密的逻辑
	 * 
	 * @param user
	 * @return
	 */
	public User encryption(User user) {
		// 加密算法、加密的原始值、加密盐值、迭代次数
		String salt = "123456";
		String paw = "123456";
		String newPaw = new SimpleHash("SHA-256", paw, ByteSource.Util.bytes(salt), 1024).toBase64();
		System.out.println(newPaw);
		user.setPwd(newPaw);
		return user;
	}
}
