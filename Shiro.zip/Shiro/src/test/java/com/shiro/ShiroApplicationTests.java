package com.shiro;

import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ShiroApplicationTests {

	@Test
	public void contextLoads() {
		//加密算法、加密的原始值、加密盐值、迭代次数
		
		String salt = "123456";
		ByteSource salt1 = ByteSource.Util.bytes(salt);
		System.out.println(salt1);
		String newPaw =  new SimpleHash("SHA-256", "123456", ByteSource.Util.bytes(salt),1024).toBase64();
		System.out.println(newPaw);
	}

}
